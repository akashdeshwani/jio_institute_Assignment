import math
import re

class Bayes_Classifier:

    def __init__(self):
        pass


    def train(self, lines):
        pass


    def classify(self, lines):
        pass
